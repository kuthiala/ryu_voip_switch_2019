**************************README DOCKER******************************

Before running the docker container after using 'docker build'

Command to run if using sudo:

xhost local:root

This exposes the port being used by the local user to the root


Docker run command:

sudo docker run -it --rm -e DISPLAY=${DISPLAY} -v /tmp/.X11-unix:/tmp/.X11-unix  --device /dev/snd -P <image_name>


The -v part mounts the X11 socket.

The -e part passes the display

.

The /dev/snd allows the host devices audio system to be used.

This exposes the x11 port and proxies the traffic from the TCP to the x11 port, while mounting the x11 socket on the container

-P publishes all the ports exposed in the dockerfile. It binds all the exposed ports to the host machine.

Using only expose means that the container should listen on those ports.

Just using expose does not allow the ports to be used for communication outside the container on a different network or the host machine. Instead of -P, we can use multiple '-p port:port' in the docker run statement.
